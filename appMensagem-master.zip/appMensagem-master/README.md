# appMensagem
Um simples webapp de mensagem criado utilizando as tecnologias node js, express e sequelize (mysql). Ministrado no Curso de Node.js - Guia do Programador do professor Victor Lima. Neste webapp criamos um pequeno CRUD com conexão ao banco de dados Mysql.


from enum import Enum


class ReportGroupType(Enum):
    MONTHLY = 0
    DAILY = 1

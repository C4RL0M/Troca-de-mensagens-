from enum import Enum


class DeliveryStatus(Enum):
    ALL = 0
    DELIVERED = 1
    UNDELIVERED = 2
